package Cloneable;

/**
 * (1)clone method in the Object class defined protected, not public. it is because NOT every object can be cloned.
 * JAVA purposefully forces the subclasses to override clone() method if an object of the subclass is cloneable.
 * (2) if you see Cloneable interface, clone() method is not defined inside of the Cloneable Interface.  Actually, Java
 * provides native method that performs a shallow copy to clone an object. Since a method in an interface is abstract
 * this native clone() method cannot be implemented the native clone() method in the Object class.
 * (3)Then, you will have question why Object class does not implement Cloneable
 * interface? Because clone() method is in the Object class.
 * (4) then what happened if this House class does not implement Cloneable interface?  Then, it would return null because super.clone() would throw
 * a CloneNotSUpportedException
 *
 */
/**
 * 2. The native Keyword in Java
 *
 * First of all, let's discuss what is a native keyword in Java.
 *
 * Simply put, this is a non-access modifier that
 * is used to access methods implemented in
 * a language other than Java like C/C++.
 *
 * It indicates platform-dependent implementation of a
 * method or code and also acts as an interface between JNI and other programming languages.
 * 3. native Methods
 *
 * A native method is a Java method (either an instance method or a class method) whose implementation is also written in another programming language such as C/C++.
 */


import java.util.Date;

public class House implements Cloneable, Comparable<House> {
    private int id;
    private double area;
    private java.util.Date whenBuilt;

    public House(int id, double area){
        this.id = id;
        this.area = area;
        whenBuilt = new java.util.Date();
    }

    //getters only
    public int getId() {
        return id;
    }

    public double getArea() {
        return area;
    }

    public Date getWhenBuilt() {
        return whenBuilt;
    }

    /** this is shallow copy.
     *
     * explain about (House)super.clone() on line 35
     *          * this method in the Object class copies each field from the original object to the target object.
     *          * if the field is of a primitive type, its value is copied. For
     *          example, the value of area (double type)
     *          * is copied from house1 to house2.
     *          * If the field is of an object, the reference of the field is copied. For example, the field
     *          * whenBuilt is of the Date class, so its reference is copied into house2 as the diagram that I am drawing
     *          * now ...  therefore, house1.whenBuildt == house2.whenBuilt will be true.
     *          * Although house1 == house2 is false.  if you go to
     *          https://docs.oracle.com/en/java/javase/11/docs/api/java.base/java/lang/Object.html#clone()
     *          * then, clone() method from the Object class is first x.clone() != x
     *          */

     public Object cloneShallow(){
        try{
            return super.clone();
        }catch(CloneNotSupportedException e){
            return null;
        }
    }


    //this is for deep copy  1
    /** Override the protected clone method defined in
     the Object class, and strengthen its accessibility */
    //if the House class did not override the clone() or if House did not implement java.lang.Cloneable,
    //then the program will receive a syntax error because clone() is protected in java.lang.Object when you run
    //House house = (House)new House().clone(); //because clone() is not visible.
    @Override
    public Object clone() throws CloneNotSupportedException {
        // Perform a shallow copy
        House houseClone = (House)super.clone(); //clone() is invoked and then cast the returned Object to House Type
      //   Object houseClone2 = super.clone();  //as you see the cloneShallow(),
        //   this is a shallow copy.
                //related to cast
        //but in previous case with other example
        // like ((SimpleType)property).getType();
        // this first casts the property to SimpleType.
        // cast from abstract or interface to concrete
        //then invoke getType() on the SimpleType.
        /**
         * explain about (House)super.clone() on line 61
         * this method in the Object class copies each field from the original object to the target object.
         * if the field is of a primitive type, it's value is copied. For example, the value of area (double type)
         * is copied from house1 to house2.
         * If the field is of an object, the reference of the field is copied. For example, the field
         * whenBuilt is of the Date class, so its reference is copied into house2 as the diagram that I am drawing
         * now ...  therefore, house1.whenBuildt == house2.whenBuilt will be false because house1 and house2 contain two different Date objects
         * Although house1 == house2 is false.  if you go to https://docs.oracle.com/en/java/javase/11/docs/api/java.base/java/lang/Object.html#clone()
         * then, clone() method from the Object class is first x.clone() != x
         * so when it is cloned, if the field is of an object type, the object's reference is copied rather
         * than its contends. This is shallow copy and add followings
         *
         */

        // Deep copy on whenBuilt
        houseClone.whenBuilt = (java.util.Date)(whenBuilt.clone());
        return houseClone;
    }


    //Deep copy 2
    //this one does not need to invoke clone() method in the Object class to perform the deep clone.
    public Object cloneDeep2(){
        //performe a shallow copy
        House houseClone = new House(id, area);
        //deep copy on whenBuilt
        houseClone.whenBuilt = new Date(); //create a new Date object
        houseClone.getWhenBuilt().setTime(whenBuilt.getTime());
        return houseClone;
    }
    @Override
    public int compareTo(House o) {
        if(this.area > o.area){
            return 1;
        }
        else if(this.area < o.area){
            return -1;
        }
        else
            return 0;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        House that = (House) o;
        return this.id == (((House) o).getId()) &&
                this.whenBuilt.equals(((House) o).whenBuilt)
                && this.area == (((House) o).getArea());
    }

}
