package Cloneable;


public class FooTester {
    public static void main(String[] args) throws CloneNotSupportedException {
        Foo foo = (Foo)new Foo().clone();
        Foo f1 = new Foo();
        System.out.println(foo.x);
        System.out.println(f1.x);
    }
}

//incorrect - find out what is wrong with Foo class.

//class Foo{
//    int x = 5;
//    public Object clone() throws CloneNotSupportedException{
//        return super.clone();
//    }
//}

//correct
class Foo implements Cloneable{
    int x = 5;
    public Object clone() throws CloneNotSupportedException{
        return super.clone();
    }
}