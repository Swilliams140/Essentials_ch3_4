package Cloneable;

public class PersonTester {
    //first without clone.
  // public static void main(String[] args) throws CloneNotSupportedException {
    // 2  --> since we do try-catch, no need to declare.

    //1
     public static void main(String[] args)  {
        Person p = new Person("Bob");
        Person b = new Person("Bob");
            System.out.println(p.equals(b)); //true  --> without clone(), it will
         // return true.
            System.out.println(p == b); //false
            System.out.println(p.getName().equals(b.getName())); //true



          //show this one at the end. and don't use (2) keep using (1)
    try{
       Person c = null;

     c = (Person)p.clone();  //3
    System.out.println("p.getName(): " + p.getName());
    System.out.println("c.getName(): " + c.getName());
    System.out.println("*****p.getName().equals(c.getName()): " + p.getName().equals
          (c.getName())); //4
}catch(CloneNotSupportedException ex){
    System.out.println("CloneNotSupportedException occurred");
}
catch(NullPointerException ex){
    System.out.println("Null pointer exception occurred");
}



    }

}
