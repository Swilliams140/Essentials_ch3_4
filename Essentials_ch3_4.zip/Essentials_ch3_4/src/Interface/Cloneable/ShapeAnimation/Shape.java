package ShapeAnimation;

public abstract class Shape implements Comparable<Shape>, Animation {

    private String color;
    private boolean filled;

    public Shape(String color, boolean filled)
    {
        super();
        this.color = color;
        this.filled = filled;
    }

    //getters and setters for color and filled (not shown)

    public abstract double area();

    @Override
    public String toString()
    {
        return "[color=" + color + ", filled=" + filled + "]";
    }

    @Override
    public int compareTo(Shape o)
    {
        if (this.area() > o.area())
            return 1;
        else if (this.area() < o.area())
            return -1;
        else
            return 0;
    }

    @Override
    public void talk()
    {
        System.out.println("I am " + this.toString());
    }
}
