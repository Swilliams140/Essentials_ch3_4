package ShapeAnimation;

public interface Animation {
    void talk(); //Simulate talking by displaying (printing) a message
    void flipRight(); //flip to the right (mirror)
}
