package ShapeAnimation;

public class AnimateShapesTexts {

    public static void main(String[] args)
    {
        Animation a;

        a = new Circle("blue", true, 30, 30, 5);  // center at (30, 30), radius 5
        a.talk();
        a.flipRight();
        a.talk();

        a = new Rectangle("orange", false, 50, 100, 30, 15); // upper-left corner (50, 100), width 30, height 15
        a.talk();
        a.flipRight();
        a.talk();

        a = new Text("hello");
        a.talk();
        a.flipRight();
        a.talk();



        
    }
}
