package ShapeAnimation;

public class AnimateShapesTextsLoop {
    public static void main(String[] args)
    {
        Animation[] shapesAndTexts = new Animation[3]; //arrays

        shapesAndTexts[0] = new Circle("blue", true, 30, 30, 5);  // center at (30, 30), radius 5
        shapesAndTexts[1] = new Rectangle("orange", false, 50, 100, 30, 15); // upper-left corner (50, 100), width 30, height 15
        shapesAndTexts[2] = new Text("hello");

        for (Animation a: shapesAndTexts)
        {
            a.talk();
            a.flipRight();
            a.talk();
            System.out.println();
        }
    }
}
