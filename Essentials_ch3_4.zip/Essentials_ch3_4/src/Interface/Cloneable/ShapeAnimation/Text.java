package ShapeAnimation;

public class Text implements Animation{
    private String text;
    public Text(String text){
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return "Text [text=" + text + "]";
    }

    @Override
    public void talk()
    {
        System.out.println("I am " + this.toString());
    }

    @Override
    public void flipRight()
    {
        //reverse the text
        String newText = "";
        for (int i = text.length()-1; i >= 0; i--)
        {
            newText = newText + text.charAt(i);
        }
        text = newText;
    }
}
