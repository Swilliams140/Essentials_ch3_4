package ShapeFullAnimation;

public interface Animation {
     void talk(); //Simulate talking by displaying (printing) a
    // message     this is equivalent to public abstract void talk();
    void flipRight(); //flip to the right (mirror)    this is equivalent to public
    // abstract void flipRight();
}
