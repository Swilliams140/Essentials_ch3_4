package ComparableChallengeWithMovie;

public class MovieTester {

    public static void main(String[] args) {


        Movie galaxyQuest = new Movie(new Title("Galaxy Quest"), new Rating(2.5));
        Movie m1 = new Movie();

        System.out.println("///////////////////////////////////////////////////////////////");
        System.out.println("m1 DEFAULT Rating Prints Here: " + m1.getRating().getRate());
        System.out.println("m1 DEFAULT Title Prints Here: " + m1.getTitle().getTitleFromTitleClass());
        System.out.println("///////////////////////////////////////////////////////////////");
        System.out.println("galaxyQuest.toString():  \n" + galaxyQuest.toString());
        System.out.println("m1.toString(): \n" + m1.toString());


        m1.setM1(new Movie(new Title("Star Wars"),new Rating(5.0)));
        System.out.println("///////////////////////////////////////////////////////////////");
        System.out.println("m1 Changed Rating Prints Here: " + m1.getM1().getRating().getRate());
        System.out.println("m1 Changed Title Prints Here: " + m1.getM1().getTitle().getTitleFromTitleClass());

        Movie lionKing = new Movie(new Title("Lion King"), new Rating(4.0));
        System.out.println("///////////////////////////////////////////////////////////////");
        System.out.println("Lion King Title Prints here: " +  lionKing.getRating().getRate());
        System.out.println("Lion King Ranking Prints here: " + lionKing.getTitle().getTitleFromTitleClass());
        System.out.println("///////////////////////////////////////////////////////////////");
        System.out.println("lionKing.toString():  \n" + lionKing.toString());


        Movie frozen = new Movie(new Title("Frozen"), new Rating(10.0));
        System.out.println(frozen.toString());
        System.out.println("///////////////////////////////////////////////////////////////");
        int result1 = lionKing.compareTo(frozen);
        int result2 = m1.compareTo2(galaxyQuest);
        System.out.println("result 1 of Lion King and Frozen: " + result1);
        System.out.println("result 2 of Star Wars and Galaxy Quest: " + result2);

    }
}


  class Movie implements Comparable<Movie> {

    private Title title = new Title("DEFAULT TITLE NAME");
    private Rating rating = new Rating(0.0);
    Movie m1; //this is added because of a student ask question about this keyword, so to show the differences, I added m1

    public Movie() {
        m1 = new Movie(title, rating);
    }


    public Movie(Title title, Rating rating) {

        this.title = title;
        this.rating = rating;
    }


    public Rating getRating() {
        return rating;
    }

    public void setRating(Rating rating) {
        rating = rating;
    }

    public Title getTitle() {
        return title;
    }

    public void setTitle(Title title) {
        title = title;
    }

      public Movie getM1() {
          return m1;
      }

      public void setM1(Movie m1) {
          this.m1 = m1;
      }

      @Override
    public int compareTo(Movie o) {
        //getRating() is from Movie class and getRate() is from Rate class
        // because you need to find integer value to use
        // >  or < =
        if(this.getRating().getRate() >  o.getRating().getRate()){
            return 1;
        }
        else if(this.getRating().getRate() < o.getRating().getRate()){
            return -1;
        }
        else return 0;
    }


    public int compareTo2(Movie o) {
        //getRating() is from Movie class and getRate() is from Rate class
        // because you need to find integer value to use
        // >  or < =
        if(m1.getRating().getRate() >  o.getRating().getRate()){
            return 1;
        }
        else if(m1.getRating().getRate() < o.getRating().getRate()){
            return -1;
        }
        else return 0;
    }

      @Override
      public String toString() {

          return   "Title: " + this.getTitle().getTitleFromTitleClass() + '\n' + "Rate: " + this.getRating().getRate();

    }
  }


  class Rating {
    private double rate;

    public Rating(double rate) {
        this.rate = rate;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }
}

  class Title {
    private String title;

    public Title(String title) {
        this.title = title;
    }

    public String getTitleFromTitleClass() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

}