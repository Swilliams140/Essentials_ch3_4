package Cloneable;
/**
 * (1)clone method in the Object class defined protected, not public. it is because NOT every object can be cloned.
 * JAVA purposefully forces the subclasses to override clone() method if an object of the subclass is cloneable.
 * (2) if you see Cloneable interface, clone() method is not defined inside of the Cloneable Interface.  Actually, Java
 * provides native method that performs a shallow copy to clone an object. Since a method in an interface is abstract
 * this native clone() method cannot be implemented the native clone() method in the Object class.
 * (3)Then, you will have question why Object class doe snot implement Cloneable interface? Because clone() method is in the Object class.
 *
 *
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class CloneableUsage {
    public static void main(String[] args) {

        //1
        Calendar calendar = new GregorianCalendar(2020,6,23);
        Calendar calendar1 = calendar; //calendar and calendar1 point to the same Calendar object
        Calendar calendar2 = (Calendar)calendar.clone(); //this creates new object that is the clone of calendar
        //and assign the new object's reference to calendar2.
        //so calendar and calendar2 are different objects with the same contents.

        System.out.println("calendar == calendar1 is " + (calendar == calendar1));//true
        System.out.println("calendar == calendar2 is " + (calendar == calendar2));//false

        //for content equality
        System.out.println("calendar.equals(calendar2) is " + calendar.equals(calendar2));//true

 //2
        ArrayList<Double> list1 = new ArrayList<>();
        list1.add(1.5);
        list1.add(2.5);
        list1.add(3.5);
        ArrayList<Double> list2 = (ArrayList<Double>)list1.clone();
        ArrayList<Double> list3 = list1;
        list2.add(4.5);
        list3.remove(1.5);
        System.out.println("list1 is " + list1); //list1 is [2.5, 3.5]
        System.out.println("list2 is " + list2); //list2 is [1.5, 2.5, 3.5, 4.5]
        System.out.println("list3 is " + list3); //list3 is [2.5, 3.5]
        System.out.println("list1 is " + list1); //list1 is [2.5, 3.5]

        //3 you can clone array as well.
        int[] alist1 = {1,2};
        int[] alist2 = alist1.clone();
        alist1[0] = 7;
        alist2[1] = 8;
        System.out.println("alist1 is " + Arrays.toString(alist1)); //7,2
        System.out.println("alist2 is " + Arrays.toString(alist2)); //1,8


    }
}
