package Cloneable;

public class HouseTester {
    public static void main(String[] args) throws CloneNotSupportedException{ //this throws for clone() method
        House house1 = new House(1,1750.50);
        House house2 = (House)house1.clone();

        System.out.println("house1.getWhenBuilt().equals(house2.getWhenBuilt()): " + house1.getWhenBuilt().equals(house2.getWhenBuilt())); //true
        //but
        System.out.println("house1.equals(house2): " + house1.equals(house2)); //this will return true


        House house3 = (House)house1.cloneShallow(); //this cloneShallow() does not need to throw because because
        //the cloneShallow() method catch the exception in the method so no need to declare it in the cloneShallow()
        // method header in the class House

        System.out.println("house1 == house2 1515is " + (house1 == house2));//false
        System.out.println("house1 == house3 is " + (house1 == house3));//false

        System.out.println("Deep copy: house1.getWhenBuilt == house2.getWhenBuilt is "
                + (house1.getWhenBuilt() == house2.getWhenBuilt() ));
        //false  house1 and house2 are contain two
        //differernt Date objects.
        //false  because this only shows that the reference field .. in this case, the whenBuilt
        // is copied
        //and in clone(), the houseClone.whenBuilt = (Date)(whenBuilt.clone());
        // means Date type object is creating
        //another Date object.  It means house1 and house2 contain two different Date objects.




        System.out.println("Shallow copy: house1.getWhenBuilt == house3.getWhenBuilt is "
                + (house1.getWhenBuilt() == house3.getWhenBuilt() ));
        //true  because house1 and house2 are referencing to same Date type object

        System.out.println("Deep copy: house1.equals(house2) is " + (house1.equals(house2)));
        //true because they are different object and House is null reference value. It is not non-null reference.

        System.out.println("Deep copy: house1.getWhenBuilt().equals(house2.getWhenBuilt() is "
                + house1.getWhenBuilt().equals(house2.getWhenBuilt())); //true

    }

}
