package ComparatorComparableMovie;// A Java program to demonstrate use of Comparable
//source: https://www.geeksforgeeks.org/comparable-vs-comparator-in-java/

//<1>complete this program first

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Movie implements Comparable<Movie> {
        private double rating;
        private String name;
        private int year;

        //used to sort movies by year
    @Override
    public int compareTo(Movie m){
//        if(this.year > m.year)
//        return 1;
//        else if( this.year < m.year)
//            return -1;
//        else return 0;
        return (this.year > m.year? 1: (this.year < m.year? -1: 0));
    }

    //constructor
    public Movie(String nm, double rt, int yr){
        this.name = nm;
        this.rating = rt;
        this.year = yr;
    }
    // Getter methods for accessing private data
    public double getRating() { return rating; }
    public String getName()   {  return name; }
    public int getYear()      {  return year;  }

    @Override
    public String toString(){
            return this.name + ": " + this.rating + ", " + this.year;
        }


    //main method in a driver class.
    public static void main(String[] args) {
        ArrayList<Movie> list = new ArrayList<Movie>();
        list.add(new Movie("Star Wars", 9.0, 1977));
        list.add(new Movie("Sound of Music", 10.0, 1965 ));
        list.add(new Movie("Harry Potter", 8.0, 2001));

        /////////////////////////////////////////////////////////////////////////////
        //this is for Part I and after complete the part I, commented out entirely.
        //<2> then come back here and explain about the Comaprator.
        //from sort(List<T> list)
         Collections.sort(list); //this Collections is class.  https://docs.oracle
        // .com/javase/10/docs/api/java/util/Collections.html
         //Collection is an interface but Collections is a class
        //explain this after writing this program.
        // this Collection.sort() method is the reason why we will use Comparator.
        //Collections class has a second sort() method and it takes Comparator.
        //The sort() method invokes the compare() to sort objects.
        //so (1)you need to create a class that implements Comparator( and thus the compare() method
        //that does the work previously done by compareTo()).
        //(2) make an instance of the Comparator class
        //(3) call the overloaded sort() method, giving it both the list and the instance of the
        //class that implements Comparator.
        //So you will need to create a class named RatingCompare by implementing Comparator<Movie>


        System.out.println("<1> Movies after sorting:  - this is sorted by year. ");
        //way 1
        for (Movie movie: list)
        {
            System.out.println(movie.getName() + " " +
                    movie.getRating() + " " +
                    movie.getYear());
        }


        System.out.println("////////////////OR////////////////// to print out the " +
                "list sorted by year");
        //way 2
             list.forEach(movie -> System.out.print(movie + " \n")); //based on the toString()

///////////////////////////////////////////////////////////////////////////////////////////

        //<5> will start from here.  //part II for testing
        //call Collections.sort here but must remove the previous Collections.sort and commented out part I.
        //then you will need to print sorted list

        //sort by rating : (1) create an object of ratingCompare
        //(2) call Collections.sor
        //(3) Print sorted list

        /////////////////////////////////
        System.out.println("//////////////////Sorted by rating////////////////");
        RatingCompare ratingCompare = new RatingCompare();
        Collections.sort(list,ratingCompare); //  	sort(List<T> list, Comparator<? super T> c)
        for(Movie movie: list){
            System.out.println(movie.getRating() + " " + movie.getName() + " " +
                    movie.getYear());
        }

        //or write like this by using forEach
        System.out.println("///////////////////////////////////////////////");
        list.forEach(movie -> System.out.print(movie.getRating() + " " + movie.getName() + " " +
                movie.getYear() +" \n")); //based on the toString()

        // <6>
        //call overloaded sort method with RatingCompare
        System.out.println("//////////////SORTED BY NAME//////////////////");

        NameCompare nameCompare = new NameCompare();
        Collections.sort(list, nameCompare);
        for (Movie movie: list)
            System.out.println(movie.getName() + " " +
                    movie.getRating() + " " +
                    movie.getYear());

        //or write like this
        System.out.println("//////////////SORTED BY NAME////////////////");
        list.forEach(movie -> System.out.print(movie.getName() + " " + movie.getRating() + " " +
                movie.getYear() +" \n")); //based on the toString()
    }
}

//<3> write this class
class RatingCompare implements Comparator<Movie>{
    @Override
    public int compare(Movie m1, Movie m2){
//        if(m1.getRating() < m2.getRating())  return -1;
//        else if(m1.getRating() > m2.getRating()) return 1;
//        else return 0;
       return m1.getRating() < m2.getRating()? -1: (m1.getRating() > m2.getRating()? 1: 0);

    }
}

//<4> write this class to compare Movies by name
class NameCompare implements Comparator<Movie>{
    public int compare(Movie m1, Movie m2){
        return m1.getName().compareToIgnoreCase(m2.getName());
    }//because you are compare two string values, you can define by using compareTo

}

