package Cloneable;

//1. start without implements Cloneable . then you will find when you test, you
// will find the clone() does not work. so you must show that you must implements
// Cloneable interface
//public class Person implements Cloneable{
public class Person {
    //then later use this one which you will implements Cloneable interface
    // public class Person implements Cloneable{ //this is very very very important
    // . Otherwise, you will have Exception.
    String name;

    public Person(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                '}';
    }

    //after PersonTester without clone, show this one. then, use o.equals(anotherObject) and make sure make student
    //understand
    //this will check if the object's content is the same by asking o.equals(anotherObject) because it is comparing name.
    public boolean equals(Object o) {
        o = new Person(name);
        if (!(o instanceof Person))
            return false; //a Person can't be equal to a non-person

            Person p = (Person) o; //downcasting
            return (this.name == null && p.name == null) || name.equals(p.name);

    }


    //do not include in the beginning. after tester, then add and show how to work on clone
    @Override
     public Object clone() throws CloneNotSupportedException {
     return super.clone();

    }

}
