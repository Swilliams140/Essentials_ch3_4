package CustomeException.Binary;

public class IllegalBinaryNumberException extends Exception{


    public IllegalBinaryNumberException(){
        super();
    }

    public IllegalBinaryNumberException(String message){
        super(message);
    }


}
